defmodule Sq2.Repo do
  use Ecto.Repo, otp_app: :sq2
end

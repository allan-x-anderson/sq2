defmodule Sq2.LayoutView do
  use Sq2.Web, :view
end

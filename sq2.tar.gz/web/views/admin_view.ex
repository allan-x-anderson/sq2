defmodule Sq2.AdminView do
  use Sq2.Web, :view
end

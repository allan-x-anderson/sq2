defmodule Sq2.PageView do
  use Sq2.Web, :view
end

defmodule Sq2.PageViewTest do
  use Sq2.ConnCase, async: true
end

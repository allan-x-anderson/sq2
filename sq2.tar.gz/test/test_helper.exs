ExUnit.start

Ecto.Adapters.SQL.Sandbox.mode(Sq2.Repo, :manual)


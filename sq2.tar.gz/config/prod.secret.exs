use Mix.Config

# In this file, we keep production configuration that
# you likely want to automate and keep it away from
# your version control system.
#
# You should document the content of this
# file or create a script for recreating it, since it's
# kept out of version control and might be hard to recover
# or recreate for your teammates (or you later on).
config :sq2, Sq2.Endpoint,
  secret_key_base: "9zLeLubamVKetzaaXFHzznhGdSix885EiLiw/1V1LDpOUDNCIDC7fUMuEIna2f1g"

# Configure your database
config :sq2, Sq2.Repo,
  adapter: Ecto.Adapters.Postgres,
  username: "postgres",
  password: "postgres",
  database: "sq2_prod",
  pool_size: 20
